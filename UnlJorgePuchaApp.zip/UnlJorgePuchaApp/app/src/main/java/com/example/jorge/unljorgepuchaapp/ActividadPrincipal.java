package com.example.jorge.unljorgepuchaapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ActividadPrincipal extends AppCompatActivity {
private EditText c,f;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_principal);
        Log.d("Programacion Avanzada","Jorge Luis Pucha Banegas");
        this.c=(EditText)findViewById(R.id.txtCentigrados);
        this.f=(EditText)findViewById(R.id.txtFaren);
        this.c.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                float faren;
                faren=(1.8f)*Float.parseFloat(c.getText().toString())+32;
                f.setText(""+faren);
                Toast.makeText(ActividadPrincipal.this,"Grados Farenheit es: " +f.getText().toString(), Toast.LENGTH_LONG)
                        .show();
                return false;
            }
        });
        this.f.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                float centi;
                centi=(Float.parseFloat(f.getText().toString())-32)/(1.8f);
                c.setText(""+centi);
                Toast.makeText(ActividadPrincipal.this,"Grados Centigrados es: " +c.getText().toString(), Toast.LENGTH_LONG)
                        .show();
                return false;
            }
        });
    }
}
